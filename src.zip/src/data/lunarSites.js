export const lunarSites = [
  {
    name: 'Mare Vaporum',
    score: 85,
    lat: 13.3,
    lng: 3.6,
    description: 'Sea of Vapors - centrally located mare with diverse geological features.',
    terrain: 'Mixed mare and highland',
    resources: 'Varied mineral deposits',
    scientific: 'Geological diversity'
  },
  {
    name: 'Mare Undarum',
    score: 78,
    lat: 6.8,
    lng: 68.4,
    description: 'Sea of Waves - Eastern mare with interesting features.',
    terrain: 'Irregular mare surface',
    resources: 'Moderate resource potential',
    scientific: 'Eastern nearside study'
  },
  {
    name: 'Mare Tranquillitatis',
    score: 62,
    lat: 8.5,
    lng: 31.4,
    description: 'Sea of Tranquility - Historic Apollo 11 landing site region.',
    terrain: 'Smooth mare surface',
    resources: 'Basaltic materials',
    scientific: 'Apollo heritage site'
  },
  {
    name: 'Mare Smythii',
    score: 90,
    lat: -2.5,
    lng: 87.5,
    description: 'Large mare basin on the lunar nearside-farside boundary. Excellent for radio astronomy due to Earth shielding.',
    terrain: 'Flat mare basalt',
    resources: 'High titanium content',
    scientific: 'Unique geological history'
  },
  {
    name: 'Mare Anguis',
    score: 88,
    lat: 22.6,
    lng: 67.7,
    description: 'Serpent Sea - narrow mare formation with interesting volcanic features.',
    terrain: 'Smooth basaltic plains',
    resources: 'Volcanic glass deposits',
    scientific: 'Volcanic formation study'
  },
  {
    name: 'Mare Fecunditatis',
    score: 85,
    lat: -7.8,
    lng: 51.3,
    description: 'Sea of Fertility - large mare basin with ancient volcanic history.',
    terrain: 'Extensive flat plains',
    resources: 'Iron and titanium rich',
    scientific: 'Ancient volcanism'
  },
  {
    name: 'Hesiodus A',
    score: 82,
    lat: -30.1,
    lng: -17.0,
    description: 'Well-known concentric crater with distinctive inner ring structure south of Mare Nubium.',
    terrain: 'Concentric crater structure',
    resources: 'Exposed subsurface materials',
    scientific: 'Impact mechanics and concentric crater formation'
  },
  { 
    name: 'Mare Imbrium', 
    score: 77,
    lat: 32.8,
    lng: -15.6,
    description: 'Sea of Rains - Largest mare basin with extensive lava flows.',
    terrain: 'Vast flat expanse',
    resources: 'Rich mineral variety',
    scientific: 'Impact basin study'
  },
  { 
    name: 'Palus Epidemiarum', 
    score: 73,
    lat: -32.0,
    lng: -28.2,
    description: 'Marsh of Epidemics - Small mare with unique features.',
    terrain: 'Irregular mare patches',
    resources: 'Local resource potential',
    scientific: 'Mare formation'
  },
  { 
    name: 'Mare Cognitum', 
    score: 72,
    lat: -10.0,
    lng: -23.1,
    description: 'Known Sea - Well-studied region with Ranger 7 landing.',
    terrain: 'Typical mare surface',
    resources: 'Standard mare materials',
    scientific: 'Well-characterized'
  },
  { 
    name: 'Mare Insularum', 
    score: 68,
    lat: 7.5,
    lng: -30.9,
    description: 'Sea of Islands - Mare with scattered highland masses.',
    terrain: 'Mixed terrain',
    resources: 'Diverse materials',
    scientific: 'Mare-highland boundary'
  },
  { 
    name: 'Aristarchus Crater', 
    score: 66,
    lat: 23.7,
    lng: -47.4,
    description: 'Brightest crater on the Moon with volcanic features.',
    terrain: 'Complex crater floor',
    resources: 'Volatile-rich deposits',
    scientific: 'Transient phenomena'
  },
  { 
    name: 'Mare Crisium', 
    score: 60,
    lat: 17.0,
    lng: 59.1,
    description: 'Sea of Crises - Circular mare basin visible from Earth.',
    terrain: 'Circular basin floor',
    resources: 'Basaltic resources',
    scientific: 'Basin formation'
  },
  { 
    name: 'Linné Crater', 
    score: 58,
    lat: 27.7,
    lng: 11.8,
    description: 'Small, young crater in Mare Serenitatis.',
    terrain: 'Fresh crater',
    resources: 'Exposed materials',
    scientific: 'Recent impact'
  },
  { 
    name: 'Mare Serenitatis', 
    score: 55,
    lat: 28.0,
    lng: 17.5,
    description: 'Sea of Serenity - Large circular mare with Apollo heritage.',
    terrain: 'Smooth basin floor',
    resources: 'Titanium-rich basalts',
    scientific: 'Apollo 17 proximity'
  },
  {
    name: 'Bench Crater',
    score: 53,
    lat: -3.2,
    lng: -23.4,
    description: 'Small crater near the Apollo 12 landing site with terraced bench-like walls.',
    terrain: 'Crater with benches',
    resources: 'Local sampling',
    scientific: 'Apollo 12 geology'
  },
  { 
    name: 'Palus Somni', 
    score: 52,
    lat: 14.1,
    lng: 45.0,
    description: 'Marsh of Sleep - Small lunar mare formation.',
    terrain: 'Limited mare area',
    resources: 'Basic mare resources',
    scientific: 'Small mare study'
  },
  { 
    name: 'Mare Humorum', 
    score: 50,
    lat: -24.4,
    lng: -38.6,
    description: 'Sea of Moisture - Circular mare with surrounding features.',
    terrain: 'Mare basin',
    resources: 'Standard resources',
    scientific: 'Impact study'
  },
  { 
    name: 'Clerke Crater', 
    score: 45,
    lat: 21.7,
    lng: 29.8,
    description: 'Small crater in Mare Serenitatis region.',
    terrain: 'Small crater floor',
    resources: 'Limited resources',
    scientific: 'Crater morphology'
  },
  { 
    name: 'Mare Spumans', 
    score: 40,
    lat: 1.1,
    lng: 65.1,
    description: 'Foaming Sea - Small mare south of Mare Undarum.',
    terrain: 'Limited mare surface',
    resources: 'Minimal resources',
    scientific: 'Small mare features'
  },
];

// Get site coordinates for 2D visualization
export const getSitePosition2D = (lat, lng) => {
  // Convert lat/lng to percentage position on flat map
  // Assuming standard equirectangular projection
  const x = ((lng + 180) / 360) * 100;
  const y = ((90 - lat) / 180) * 100;
  return { x: `${x}%`, y: `${y}%` };
};

// Get site coordinates for 3D globe
export const getSitePosition3D = (lat, lng, radius = 2) => {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);
  
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = (radius * Math.sin(phi) * Math.sin(theta));
  const y = (radius * Math.cos(phi));
  
  return [x, y, z];
};
