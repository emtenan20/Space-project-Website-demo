import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import SiteSelection from './pages/SiteSelection';
import Objectives from './pages/Objectives';
import Results from './pages/Results';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black text-white">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/selection" element={<SiteSelection />} />
          <Route path="/objectives" element={<Objectives />} />
          <Route path="/results" element={<Results />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
