import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Canvas } from '@react-three/fiber';
import { Stars } from '@react-three/drei';
import { GlobeAltIcon, ChartBarIcon, RocketLaunchIcon } from '@heroicons/react/24/outline';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" }
  }
};

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Animated stars background */}
      <div className="fixed inset-0 z-0">
        <Canvas>
          <Stars
            radius={300}
            depth={50}
            count={3000}
            factor={4}
            saturation={0}
            fade
            speed={0.5}
          />
        </Canvas>
      </div>

      {/* Content */}
      <motion.div
        className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 sm:px-6 lg:px-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div
          className="text-center max-w-4xl"
          variants={itemVariants}
        >
          {/* Main title */}
          <motion.h1
            className="text-4xl sm:text-5xl md:text-6xl font-semibold mb-6 text-white tracking-tight"
            variants={itemVariants}
          >
            Lunar Landing Site
            <br />
            <span className="text-lunar-blue">Selection Tool</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            className="text-lg sm:text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed font-light"
            variants={itemVariants}
          >
            Identify optimal landing sites using advanced 3D visualization,
            comprehensive lunar data, and mission-critical parameters.
          </motion.p>

          {/* Features grid */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12 max-w-3xl mx-auto"
            variants={containerVariants}
          >
            <motion.div
              className="glass rounded-2xl p-6 card-hover"
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <div className="w-10 h-10 rounded-xl bg-lunar-blue/10 flex items-center justify-center mb-4 mx-auto">
                <GlobeAltIcon className="w-5 h-5 text-lunar-blue" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">
                3D Visualization
              </h3>
              <p className="text-gray-500 text-sm">
                Explore the Moon with interactive 3D globe rendering
              </p>
            </motion.div>

            <motion.div
              className="glass rounded-2xl p-6 card-hover"
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <div className="w-10 h-10 rounded-xl bg-lunar-blue/10 flex items-center justify-center mb-4 mx-auto">
                <ChartBarIcon className="w-5 h-5 text-lunar-blue" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">
                Data-Driven
              </h3>
              <p className="text-gray-500 text-sm">
                Comprehensive analysis of terrain and environmental factors
              </p>
            </motion.div>

            <motion.div
              className="glass rounded-2xl p-6 card-hover"
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <div className="w-10 h-10 rounded-xl bg-lunar-blue/10 flex items-center justify-center mb-4 mx-auto">
                <RocketLaunchIcon className="w-5 h-5 text-lunar-blue" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">
                Mission Ready
              </h3>
              <p className="text-gray-500 text-sm">
                Customized recommendations for your mission objectives
              </p>
            </motion.div>
          </motion.div>

          {/* CTA Button */}
          <motion.button
            onClick={() => navigate('/selection')}
            className="px-8 py-4 bg-lunar-blue rounded-full text-white font-semibold text-base tracking-wide transition-all hover:bg-blue-600 active:scale-[0.98]"
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Begin Site Selection
          </motion.button>

          {/* Stats */}
          <motion.div
            className="flex flex-wrap justify-center gap-12 mt-16"
            variants={containerVariants}
          >
            <motion.div className="text-center" variants={itemVariants}>
              <div className="text-3xl font-semibold text-white mb-1">
                20+
              </div>
              <div className="text-sm text-gray-500">
                Candidate Sites
              </div>
            </motion.div>

            <motion.div className="text-center" variants={itemVariants}>
              <div className="text-3xl font-semibold text-white mb-1">
                Real-time
              </div>
              <div className="text-sm text-gray-500">
                3D Analysis
              </div>
            </motion.div>

            <motion.div className="text-center" variants={itemVariants}>
              <div className="text-3xl font-semibold text-white mb-1">
                LRO
              </div>
              <div className="text-sm text-gray-500">
                Data Source
              </div>
            </motion.div>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}
