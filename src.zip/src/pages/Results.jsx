import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import useLunarStore from '../store/useLunarStore';
import { lunarSites } from '../data/lunarSites';
import MoonViewer from '../components/MoonViewer';
import {
  TrophyIcon,
  ArrowDownTrayIcon,
  ArrowPathIcon,
  ArrowLeftIcon,
  HomeIcon,
  MapPinIcon,
  XMarkIcon,
  BeakerIcon,
  UserGroupIcon,
  CubeIcon,
  ChevronRightIcon
} from '@heroicons/react/24/outline';
import { CheckBadgeIcon } from '@heroicons/react/24/solid';

export default function Results() {
  const navigate = useNavigate();
  const { selectedSites, siteScores, missionObjective, parameters } = useLunarStore();
  const [selectedResult, setSelectedResult] = useState(null);

  // Calculate adjusted scores based on mission parameters
  const calculateAdjustedScore = (siteName) => {
    const site = lunarSites.find(s => s.name === siteName);
    if (site) return site.score;
    return siteScores[siteName] || 0;
  };

  // Get ranked results
  const rankedSites = selectedSites
    .map(siteName => {
      const site = lunarSites.find(s => s.name === siteName);
      return {
        ...site,
        adjustedScore: calculateAdjustedScore(siteName),
        baseScore: siteScores[siteName]
      };
    })
    .sort((a, b) => b.adjustedScore - a.adjustedScore);

  const topSite = rankedSites[0];

  const getMissionIcon = () => {
    switch (missionObjective) {
      case 'scientific': return BeakerIcon;
      case 'humanExploration': return UserGroupIcon;
      case 'resourceUtilization': return CubeIcon;
      default: return BeakerIcon;
    }
  };

  const getMissionLabel = () => {
    switch (missionObjective) {
      case 'scientific': return 'Scientific Research';
      case 'humanExploration': return 'Human Exploration';
      case 'resourceUtilization': return 'Resource Utilization';
      default: return 'Mission';
    }
  };

  const MissionIcon = getMissionIcon();

  const handleExport = () => {
    const reportData = {
      missionObjective,
      parameters,
      selectedSites: rankedSites,
      timestamp: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lunar-mission-report-${Date.now()}.json`;
    a.click();
  };

  const handleRestart = () => {
    if (confirm('Are you sure you want to start over? All selections will be lost.')) {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-black py-8 px-4">
      {/* Header */}
      <motion.div
        className="max-w-6xl mx-auto mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="glass-strong rounded-2xl p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-semibold text-white mb-2">
                Analysis Complete
              </h1>
              <div className="flex items-center gap-2 text-gray-400">
                <MissionIcon className="w-4 h-4" />
                <span className="text-sm">{getMissionLabel()} Profile</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleExport}
                className="flex items-center gap-2 px-4 py-2 glass rounded-full hover:bg-white/5 transition-all text-sm font-medium"
              >
                <ArrowDownTrayIcon className="w-4 h-4" />
                Export
              </button>
              <button
                onClick={handleRestart}
                className="flex items-center gap-2 px-4 py-2 glass rounded-full hover:bg-white/5 transition-all text-sm font-medium text-gray-400 hover:text-white"
              >
                <ArrowPathIcon className="w-4 h-4" />
                Restart
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Top recommendation */}
      <motion.div
        className="max-w-6xl mx-auto mb-6"
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <div className="glass-strong rounded-2xl p-6 border border-green-500/30">
          <div className="flex items-start gap-4 mb-5">
            <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center flex-shrink-0">
              <TrophyIcon className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <p className="text-xs text-green-500 font-medium uppercase tracking-wide mb-1">
                Top Recommendation
              </p>
              <h2 className="text-2xl font-semibold text-white">
                {topSite.name}
              </h2>
            </div>
            <div className="ml-auto text-right">
              <p className="text-xs text-gray-500 mb-1">Score</p>
              <p className="text-2xl font-semibold text-green-500">{topSite.adjustedScore}</p>
            </div>
          </div>

          <p className="text-gray-400 text-sm mb-5">
            {topSite.description}
          </p>

        </div>
      </motion.div>

      {/* Main content grid */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Rankings list */}
        <motion.div
          className="glass-strong rounded-2xl p-5"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h2 className="text-lg font-semibold text-white mb-4">
            Site Rankings
          </h2>

          <div className="space-y-2">
            {rankedSites.map((site, index) => (
              <motion.div
                key={site.name}
                className={`glass rounded-xl p-4 cursor-pointer transition-all ${
                  selectedResult?.name === site.name
                    ? 'border-lunar-blue bg-lunar-blue/5'
                    : 'hover:bg-white/5'
                }`}
                onClick={() => setSelectedResult(site)}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.05 }}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                    index === 0 ? 'bg-green-500 text-white' :
                    index === 1 ? 'bg-lunar-blue text-white' :
                    index === 2 ? 'bg-purple-500 text-white' :
                    'bg-white/10 text-gray-400'
                  }`}>
                    {index + 1}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-medium text-white truncate">
                      {site.name}
                    </h3>
                  </div>

                  <div className="text-right">
                    <p className="text-sm font-semibold text-white">{site.adjustedScore}</p>
                  </div>

                  <ChevronRightIcon className="w-4 h-4 text-gray-500" />
                </div>
              </motion.div>
            ))}
          </div>

          {missionObjective === 'scientific' && (
            <div className="mt-4 glass rounded-xl p-4">
              <p className="text-xs text-gray-500 mb-3">Parameter Weights</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Slope</span>
                  <span className="text-white">{parameters.slope}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Temperature</span>
                  <span className="text-white">{parameters.temperature}%</span>
                </div>
              </div>
            </div>
          )}
        </motion.div>

        {/* 3D Viewer / Details */}
        <motion.div
          className="glass-strong rounded-2xl overflow-hidden"
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          {selectedResult ? (
            <div className="p-5 h-full">
              <div className="flex justify-between items-start mb-5">
                <div className="flex items-center gap-3">
                  <CheckBadgeIcon className="w-6 h-6 text-lunar-blue" />
                  <h2 className="text-xl font-semibold text-white">
                    {selectedResult.name}
                  </h2>
                </div>
                <button
                  onClick={() => setSelectedResult(null)}
                  className="p-1 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <XMarkIcon className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              <div className="space-y-5">
                <div>
                  <p className="text-xs text-gray-500 mb-2">Description</p>
                  <p className="text-gray-300 text-sm">{selectedResult.description}</p>
                </div>

                <div className="glass rounded-xl p-4">
                  <p className="text-xs text-gray-500 mb-1">Score</p>
                  <p className="text-2xl font-semibold text-green-500">
                    {selectedResult.adjustedScore}
                  </p>
                </div>


                <div className="glass rounded-xl p-4 bg-lunar-blue/5 border border-lunar-blue/20">
                  <div className="flex items-center gap-2">
                    <MapPinIcon className="w-4 h-4 text-lunar-blue" />
                    <p className="text-xs text-gray-400">Coordinates</p>
                  </div>
                  <p className="text-white font-medium mt-1">
                    {selectedResult.lat.toFixed(2)}°, {selectedResult.lng.toFixed(2)}°
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-[500px] relative">
              <MoonViewer
                selectedSites={selectedSites}
                onSiteClick={() => {}}
              />
              <div className="absolute top-4 left-4 glass rounded-xl p-3">
                <p className="text-xs text-gray-400">
                  Select a site from rankings to view details
                </p>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Bottom actions */}
      <motion.div
        className="max-w-6xl mx-auto mt-6 flex justify-center gap-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <button
          onClick={() => navigate('/objectives')}
          className="flex items-center gap-2 px-5 py-2.5 glass rounded-full hover:bg-white/5 transition-all text-sm font-medium"
        >
          <ArrowLeftIcon className="w-4 h-4" />
          Adjust Parameters
        </button>

        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 px-6 py-2.5 bg-lunar-blue rounded-full text-white font-medium text-sm hover:bg-blue-600 transition-all"
        >
          <HomeIcon className="w-4 h-4" />
          Return Home
        </button>
      </motion.div>
    </div>
  );
}
