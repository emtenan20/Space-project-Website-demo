import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import useLunarStore from '../store/useLunarStore';
import {
  BeakerIcon,
  UserGroupIcon,
  CubeIcon,
  ArrowLeftIcon,
  ArrowRightIcon,
  CheckIcon
} from '@heroicons/react/24/outline';

const objectives = [
  {
    id: 'scientific',
    title: 'Scientific Research',
    icon: BeakerIcon,
    description: 'Optimize for geological diversity, sample collection, and scientific discovery potential.'
  },
  {
    id: 'humanExploration',
    title: 'Human Exploration',
    icon: UserGroupIcon,
    description: 'Prioritize crew safety, habitable terrain, and accessibility for sustained human presence.'
  },
  {
    id: 'resourceUtilization',
    title: 'Resource Utilization',
    icon: CubeIcon,
    description: 'Focus on resource extraction, water ice deposits, and in-situ resource utilization potential.'
  }
];

const parameters = [
  {
    id: 'slope',
    label: 'Terrain Slope',
    description: 'Lower slope values indicate flatter, safer landing terrain'
  },
  {
    id: 'temperature',
    label: 'Temperature Range',
    description: 'Moderate temperatures reduce thermal management challenges'
  }
];

export default function Objectives() {
  const navigate = useNavigate();
  const { missionObjective, setMissionObjective, parameters: storeParams, setParameter } = useLunarStore();
  const [showParameters, setShowParameters] = useState(missionObjective === 'scientific');

  const handleObjectiveSelect = (objectiveId) => {
    setMissionObjective(objectiveId);
    setShowParameters(objectiveId === 'scientific');
  };

  const handleContinue = () => {
    if (!missionObjective) {
      alert('Please select a mission objective');
      return;
    }
    navigate('/results');
  };

  return (
    <div className="min-h-screen bg-black py-12 px-4">
      {/* Header */}
      <motion.div
        className="max-w-4xl mx-auto mb-10"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl sm:text-4xl font-semibold text-white mb-3">
          Mission Objectives
        </h1>
        <p className="text-base text-gray-500">
          Define your mission goals to customize site rankings and analysis criteria
        </p>
      </motion.div>

      {/* Objectives cards */}
      <div className="max-w-5xl mx-auto mb-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {objectives.map((objective, index) => {
            const IconComponent = objective.icon;
            return (
              <motion.div
                key={objective.id}
                className={`glass-strong rounded-2xl p-6 cursor-pointer transition-all ${
                  missionObjective === objective.id
                    ? 'border-lunar-blue bg-lunar-blue/5'
                    : 'hover:bg-white/5'
                }`}
                onClick={() => handleObjectiveSelect(objective.id)}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-4">
                  <IconComponent className={`w-6 h-6 ${
                    missionObjective === objective.id ? 'text-lunar-blue' : 'text-gray-400'
                  }`} />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  {objective.title}
                </h3>
                <p className="text-gray-500 text-sm mb-4">
                  {objective.description}
                </p>

                <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                  missionObjective === objective.id
                    ? 'bg-lunar-blue'
                    : 'border border-gray-600'
                }`}>
                  {missionObjective === objective.id && (
                    <CheckIcon className="w-4 h-4 text-white" />
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Parameters section */}
      {showParameters && (
        <motion.div
          className="max-w-3xl mx-auto glass-strong rounded-2xl p-6"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-white mb-2">
              Customize Parameters
            </h2>
            <p className="text-gray-500 text-sm">
              Adjust the importance of each parameter for your scientific mission.
              Higher values indicate greater priority in site ranking.
            </p>
          </div>

          <div className="space-y-6">
            {parameters.map((param, index) => (
              <motion.div
                key={param.id}
                className="glass rounded-xl p-5"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="text-base font-medium text-white mb-1">
                      {param.label}
                    </h3>
                    <p className="text-xs text-gray-500">
                      {param.description}
                    </p>
                  </div>
                  <span className="text-lg font-semibold text-lunar-blue">
                    {storeParams[param.id]}%
                  </span>
                </div>

                <input
                  type="range"
                  min="0"
                  max="100"
                  value={storeParams[param.id]}
                  onChange={(e) => setParameter(param.id, parseInt(e.target.value))}
                  className="w-full"
                />

                <div className="flex justify-between text-xs text-gray-600 mt-2">
                  <span>Low Priority</span>
                  <span>High Priority</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Navigation */}
      <motion.div
        className="max-w-4xl mx-auto mt-10 flex justify-between items-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <button
          onClick={() => navigate('/selection')}
          className="flex items-center gap-2 px-6 py-3 glass rounded-full hover:bg-white/5 transition-all font-medium"
        >
          <ArrowLeftIcon className="w-4 h-4" />
          Back
        </button>

        <button
          onClick={handleContinue}
          disabled={!missionObjective}
          className={`flex items-center gap-2 px-8 py-3 rounded-full font-medium transition-all ${
            !missionObjective
              ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
              : 'bg-lunar-blue text-white hover:bg-blue-600'
          }`}
        >
          View Results
          <ArrowRightIcon className="w-4 h-4" />
        </button>
      </motion.div>
    </div>
  );
}
