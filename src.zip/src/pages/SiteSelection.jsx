import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import useLunarStore from '../store/useLunarStore';
import MoonViewer from '../components/MoonViewer';
import { lunarSites } from '../data/lunarSites';
import {
  MagnifyingGlassIcon,
  ListBulletIcon,
  GlobeAltIcon,
  MapPinIcon,
  CheckIcon,
  ArrowLeftIcon,
  ArrowRightIcon,
  CursorArrowRaysIcon,
  HandRaisedIcon
} from '@heroicons/react/24/outline';
import { CheckCircleIcon } from '@heroicons/react/24/solid';

export default function SiteSelection() {
  const navigate = useNavigate();
  const { selectedSites, toggleSite } = useLunarStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('3d');
  const [hoveredSite, setHoveredSite] = useState(null);

  const filteredSites = lunarSites.filter(site =>
    site.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSiteClick = (siteName, score) => {
    toggleSite(siteName, score);
  };

  const handleContinue = () => {
    if (selectedSites.length === 0) {
      alert('Please select at least 1 site');
      return;
    }
    navigate('/objectives');
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <motion.div
        className="fixed top-0 left-0 right-0 z-50 glass-strong"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl sm:text-2xl font-semibold text-white">
              Select Landing Sites
            </h1>
            <p className="text-sm text-gray-500">
              Choose 1-5 candidate regions for analysis
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="glass rounded-full px-4 py-2">
              <span className="text-lunar-blue font-medium">
                {selectedSites.length} / 5
              </span>
            </div>

            <button
              onClick={() => setViewMode(viewMode === '3d' ? 'list' : '3d')}
              className="glass rounded-full p-2.5 hover:bg-white/5 transition-all"
            >
              {viewMode === '3d' ? (
                <ListBulletIcon className="w-5 h-5 text-white" />
              ) : (
                <GlobeAltIcon className="w-5 h-5 text-white" />
              )}
            </button>
          </div>
        </div>
      </motion.div>

      {/* Main content */}
      <div className="pt-24 pb-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left panel - Site list */}
            <motion.div
              className="lg:col-span-1 glass-strong rounded-2xl p-5 max-h-[calc(100vh-200px)] overflow-hidden flex flex-col"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* Search */}
              <div className="mb-4 relative">
                <MagnifyingGlassIcon className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search sites..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-lunar-blue/50 transition-all text-sm"
                />
              </div>

              {/* Sites list */}
              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {filteredSites.map((site, index) => (
                  <motion.div
                    key={site.name}
                    className={`glass rounded-xl p-4 cursor-pointer transition-all ${
                      selectedSites.includes(site.name)
                        ? 'bg-lunar-blue/10 border-lunar-blue/50'
                        : 'hover:bg-white/5'
                    }`}
                    onClick={() => handleSiteClick(site.name, site.score)}
                    onMouseEnter={() => setHoveredSite(site)}
                    onMouseLeave={() => setHoveredSite(null)}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.03 }}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-white text-sm mb-1 truncate">
                          {site.name}
                        </h3>
                        <p className="text-xs text-gray-500 line-clamp-2">
                          {site.terrain}
                        </p>
                      </div>

                      <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                        selectedSites.includes(site.name)
                          ? 'bg-lunar-blue'
                          : 'border border-gray-600'
                      }`}>
                        {selectedSites.includes(site.name) && (
                          <CheckIcon className="w-3 h-3 text-white" />
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Right panel - 3D viewer or details */}
            <motion.div
              className="lg:col-span-2 glass-strong rounded-2xl overflow-hidden"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              {viewMode === '3d' ? (
                <div className="h-[600px] lg:h-[calc(100vh-200px)] relative">
                  <MoonViewer
                    selectedSites={selectedSites}
                    onSiteClick={handleSiteClick}
                  />

                  {/* Instructions overlay */}
                  <div className="absolute top-4 left-4 glass rounded-xl p-4 max-w-xs">
                    <h3 className="font-medium text-white text-sm mb-3">
                      Controls
                    </h3>
                    <ul className="text-xs text-gray-400 space-y-2">
                      <li className="flex items-center gap-2">
                        <HandRaisedIcon className="w-4 h-4 text-gray-500" />
                        <span>Drag to rotate</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <MagnifyingGlassIcon className="w-4 h-4 text-gray-500" />
                        <span>Scroll to zoom</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CursorArrowRaysIcon className="w-4 h-4 text-gray-500" />
                        <span>Click markers to select</span>
                      </li>
                    </ul>
                    <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-4 text-xs">
                      <span className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-lunar-blue"></span>
                        <span className="text-gray-400">Available</span>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-green-500"></span>
                        <span className="text-gray-400">Selected</span>
                      </span>
                    </div>
                  </div>

                  {/* Hovered site info */}
                  <AnimatePresence>
                    {hoveredSite && (
                      <motion.div
                        className="absolute bottom-4 left-4 right-4 glass-strong rounded-xl p-5"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <h3 className="text-lg font-semibold text-white">
                            {hoveredSite.name}
                          </h3>
                          {selectedSites.includes(hoveredSite.name) && (
                            <CheckCircleIcon className="w-5 h-5 text-green-500" />
                          )}
                        </div>
                        <p className="text-gray-400 text-sm mb-4">
                          {hoveredSite.description}
                        </p>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500 text-xs">Terrain</span>
                            <p className="text-white mt-0.5">{hoveredSite.terrain}</p>
                          </div>
                          <div>
                            <span className="text-gray-500 text-xs">Resources</span>
                            <p className="text-white mt-0.5">{hoveredSite.resources}</p>
                          </div>
                          <div>
                            <span className="text-gray-500 text-xs">Scientific Value</span>
                            <p className="text-white mt-0.5">{hoveredSite.scientific}</p>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="p-5 h-[600px] lg:h-[calc(100vh-200px)] overflow-y-auto">
                  <h2 className="text-lg font-semibold text-white mb-4">
                    Selected Sites ({selectedSites.length})
                  </h2>
                  {selectedSites.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 text-center">
                      <MapPinIcon className="w-12 h-12 text-gray-600 mb-4" />
                      <p className="text-gray-500">
                        No sites selected yet.
                        <br />
                        Click on sites from the list to add them.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {selectedSites.map((siteName) => {
                        const site = lunarSites.find(s => s.name === siteName);
                        return (
                          <motion.div
                            key={siteName}
                            className="glass rounded-xl p-5 border border-lunar-blue/30"
                            initial={{ opacity: 0, scale: 0.98 }}
                            animate={{ opacity: 1, scale: 1 }}
                          >
                            <div className="flex justify-between items-start mb-3">
                              <h3 className="text-base font-semibold text-white">
                                {site.name}
                              </h3>
                              <button
                                onClick={() => handleSiteClick(siteName, site.score)}
                                className="text-gray-500 hover:text-red-400 transition-colors text-sm"
                              >
                                Remove
                              </button>
                            </div>
                            <p className="text-gray-400 text-sm mb-4">{site.description}</p>
                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div>
                                <span className="text-gray-500 text-xs">Terrain</span>
                                <p className="text-white mt-0.5">{site.terrain}</p>
                              </div>
                              <div>
                                <span className="text-gray-500 text-xs">Resources</span>
                                <p className="text-white mt-0.5">{site.resources}</p>
                              </div>
                              <div>
                                <span className="text-gray-500 text-xs">Scientific</span>
                                <p className="text-white mt-0.5">{site.scientific}</p>
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <motion.div
        className="fixed bottom-0 left-0 right-0 glass-strong py-4"
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 px-5 py-2.5 glass rounded-full hover:bg-white/5 transition-all text-sm font-medium"
          >
            <ArrowLeftIcon className="w-4 h-4" />
            Back
          </button>

          <button
            onClick={handleContinue}
            disabled={selectedSites.length === 0}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-full font-medium text-sm transition-all ${
              selectedSites.length === 0
                ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                : 'bg-lunar-blue text-white hover:bg-blue-600'
            }`}
          >
            Continue
            <ArrowRightIcon className="w-4 h-4" />
          </button>
        </div>
      </motion.div>
    </div>
  );
}
