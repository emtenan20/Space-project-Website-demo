import { useEffect, useRef } from "react";
import * as Cesium from "cesium";
import "cesium/Build/Cesium/Widgets/widgets.css";
import { lunarSites } from "../data/lunarSites";

const MOON_RADIUS_M = 1737400.0; 
const moonEllipsoid = new Cesium.Ellipsoid(MOON_RADIUS_M, MOON_RADIUS_M, MOON_RADIUS_M);

function moonCartesianFromDegrees(lonDeg, latDeg, heightMeters = 0) {
  const carto = Cesium.Cartographic.fromDegrees(lonDeg, latDeg, heightMeters);
  return moonEllipsoid.cartographicToCartesian(carto);
}

export default function MoonViewer({ selectedSites = [], onSiteClick }) {
  const cesiumContainer = useRef(null);
  const viewerRef = useRef(null);

  
  const entityByNameRef = useRef(new Map());

  useEffect(() => {
    if (!cesiumContainer.current || viewerRef.current) return;

    
    Cesium.Ion.defaultAccessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJmOWQ2ZmQwZi0xNTYyLTQ0MjUtYjljZC0wNGJhYjA0N2EzOWIiLCJpZCI6Mzg3MDc5LCJpYXQiOjE3NzAyMzAyMTF9.voGr_xQcuU79mBiOBX0P3LxMJY-fEruRXNqcmXTS_EI";

    const viewer = new Cesium.Viewer(cesiumContainer.current, {
      baseLayerPicker: false,
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      navigationHelpButton: false,
      animation: false,
      timeline: false,
      fullscreenButton: false,
      vrButton: false,
      infoBox: false,
      selectionIndicator: false,

      
      terrainProvider: new Cesium.EllipsoidTerrainProvider(),
    });

    
    viewer.imageryLayers.removeAll();
    viewer.scene.globe.show = false;

    
    viewer.scene.backgroundColor = Cesium.Color.BLACK;
    viewer.scene.skyAtmosphere.show = false;

    let destroyed = false;

    (async () => {
      try {
        
        const tileset = await Cesium.Cesium3DTileset.fromIonAssetId(2684829);
        if (destroyed) return;

        viewer.scene.primitives.add(tileset);

        // Zoom camera to the Moon tileset when ready
        await viewer.zoomTo(tileset);

        // Add markers (using a Moon ellipsoid conversion)
        entityByNameRef.current.clear();
        viewer.entities.removeAll();

        for (const site of lunarSites) {
          const isSelected = selectedSites.includes(site.name);

          const entity = viewer.entities.add({
            name: site.name,
            position: moonCartesianFromDegrees(site.lng, site.lat, 1000), // slightly above surface
            point: {
              pixelSize: 12,
              color: isSelected ? Cesium.Color.GREEN : Cesium.Color.CYAN,
              outlineColor: Cesium.Color.WHITE,
              outlineWidth: 3,
              disableDepthTestDistance: Number.POSITIVE_INFINITY,
            },
            label: {
              text: site.name,
              font: "16px sans-serif",
              fillColor: Cesium.Color.WHITE,
              outlineColor: Cesium.Color.BLACK,
              outlineWidth: 3,
              style: Cesium.LabelStyle.FILL_AND_OUTLINE,
              verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
              pixelOffset: new Cesium.Cartesian2(0, -12),
              showBackground: true,
              backgroundColor: new Cesium.Color(0, 0, 0, 0.7),
              disableDepthTestDistance: Number.POSITIVE_INFINITY,
            },
          });

          entityByNameRef.current.set(site.name, entity);
        }
      } catch (err) {
        console.error("Failed to load Cesium Moon (Ion asset 2684829):", err);
        console.error(
          "If you see a 404 on /v1/assets/2684829/endpoint, your token is not from the same Ion account or lacks asset access."
        );
      }
    })();

    
    viewer.screenSpaceEventHandler.setInputAction((click) => {
      const picked = viewer.scene.pick(click.position);
      if (Cesium.defined(picked) && picked.id?.name) {
        const site = lunarSites.find((s) => s.name === picked.id.name);
        if (site && typeof onSiteClick === "function") {
          onSiteClick(site.name, site.score);
        }
      }
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);

    viewerRef.current = viewer;

    return () => {
      destroyed = true;
      try {
        viewerRef.current?.destroy();
      } finally {
        viewerRef.current = null;
      }
    };
  }, []);

  
  useEffect(() => {
    const map = entityByNameRef.current;
    if (!map || map.size === 0) return;

    for (const [name, entity] of map.entries()) {
      const isSelected = selectedSites.includes(name);
      if (entity.point) {
        entity.point.color = isSelected ? Cesium.Color.GREEN : Cesium.Color.CYAN;
      }
    }
  }, [selectedSites]);

  return (
    <div
      ref={cesiumContainer}
      className="w-full h-full"
      style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
    />
  );
}