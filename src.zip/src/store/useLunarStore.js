import { create } from 'zustand';

const useLunarStore = create((set) => ({
  // Selected sites
  selectedSites: [],
  siteScores: {},

  // Mission objectives
  missionObjective: null,
  parameters: {
    slope: 50,
    temperature: 50,
  },

  // Actions
  setSelectedSites: (sites) => set({ selectedSites: sites }),

  toggleSite: (siteName, score) => set((state) => {
    const isSelected = state.selectedSites.includes(siteName);

    if (isSelected) {
      const newSites = state.selectedSites.filter(s => s !== siteName);
      const newScores = { ...state.siteScores };
      delete newScores[siteName];
      return { selectedSites: newSites, siteScores: newScores };
    } else {
      if (state.selectedSites.length >= 5) return state;
      return {
        selectedSites: [...state.selectedSites, siteName],
        siteScores: { ...state.siteScores, [siteName]: score }
      };
    }
  }),

  setMissionObjective: (objective) => set({ missionObjective: objective }),

  setParameter: (param, value) => set((state) => ({
    parameters: { ...state.parameters, [param]: value }
  })),

  resetStore: () => set({
    selectedSites: [],
    siteScores: {},
    missionObjective: null,
    parameters: { slope: 50, temperature: 50 }
  }),
}));

export default useLunarStore;
